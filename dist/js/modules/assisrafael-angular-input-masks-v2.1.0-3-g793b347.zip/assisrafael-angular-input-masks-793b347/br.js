module.exports = require('./src/angular-input-masks.br');
